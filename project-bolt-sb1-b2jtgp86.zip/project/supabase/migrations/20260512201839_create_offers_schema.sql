/*
  # ProPhone Offers Schema

  1. New Tables
    - `categories`
      - `id` (uuid, primary key)
      - `name` (text) - category name (e.g. Samsung, iPhone, Accessories)
      - `name_ar` (text) - Arabic name
      - `icon` (text) - icon name/emoji
      - `created_at` (timestamptz)

    - `offers`
      - `id` (uuid, primary key)
      - `title` (text) - offer title
      - `title_ar` (text) - Arabic title
      - `description` (text) - description
      - `description_ar` (text) - Arabic description
      - `original_price` (numeric) - original price
      - `offer_price` (numeric) - discounted price
      - `image_url` (text) - product image URL
      - `category_id` (uuid, FK to categories)
      - `badge` (text) - badge label like "جديد", "خصم", "محدود"
      - `badge_ar` (text)
      - `is_active` (boolean) - whether offer is live
      - `expires_at` (timestamptz) - offer expiry date
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled on both tables
    - Public read access for active offers and categories
    - Authenticated users (admins) can insert/update/delete
*/

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  name_ar text NOT NULL DEFAULT '',
  icon text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read categories"
  ON categories FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can insert categories"
  ON categories FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can update categories"
  ON categories FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can delete categories"
  ON categories FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  title_ar text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  description_ar text NOT NULL DEFAULT '',
  original_price numeric(10,2) NOT NULL DEFAULT 0,
  offer_price numeric(10,2) NOT NULL DEFAULT 0,
  image_url text NOT NULL DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  badge text NOT NULL DEFAULT '',
  badge_ar text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read active offers"
  ON offers FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated can insert offers"
  ON offers FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can update offers"
  ON offers FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can delete offers"
  ON offers FOR DELETE
  TO authenticated
  USING (true);
