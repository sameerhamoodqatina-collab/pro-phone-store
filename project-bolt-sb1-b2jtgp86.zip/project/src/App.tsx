import { useState, useEffect, useCallback } from 'react';
import { supabase, type Offer, type Category } from './lib/supabase';
import './App.css';

function calcDiscount(original: number, offer: number) {
  return Math.round(((original - offer) / original) * 100);
}

function getDaysLeft(expiresAt: string | null): number | null {
  if (!expiresAt) return null;
  const diff = new Date(expiresAt).getTime() - Date.now();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function BadgeClass(badge: string) {
  const b = badge.toLowerCase();
  if (b === 'new' || b === 'جديد') return 'new';
  if (b === 'limited' || b === 'محدود') return 'limited';
  if (b === 'sale' || b === 'تخفيض') return 'sale';
  return '';
}

function ExpiresLabel({ expiresAt }: { expiresAt: string | null }) {
  const days = getDaysLeft(expiresAt);
  if (days === null) return null;
  if (days <= 0) return <span className="expires-text urgent">⏰ انتهى العرض</span>;
  if (days <= 3) return <span className="expires-text urgent">⏰ آخر {days} أيام</span>;
  if (days <= 7) return <span className="expires-text soon">⏱ {days} أيام متبقية</span>;
  return <span className="expires-text">📅 {days} يوم متبقي</span>;
}

function OfferModal({ offer, onClose }: { offer: Offer; onClose: () => void }) {
  const discount = calcDiscount(offer.original_price, offer.offer_price);

  function handleShare() {
    const text = `عرض بروفون: ${offer.title_ar} بسعر ${offer.offer_price} د.ج فقط!\n(كان ${offer.original_price} د.ج)`;
    if (navigator.share) {
      navigator.share({ title: 'عرض بروفون', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text).then(() => alert('تم نسخ تفاصيل العرض'));
    }
  }

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="modal-close" onClick={onClose} aria-label="إغلاق">✕</button>
        <img src={offer.image_url} alt={offer.title_ar} className="modal-image" />
        <div className="modal-body">
          {offer.badge_ar && (
            <span className="modal-badge">{offer.badge_ar}</span>
          )}
          {offer.categories && (
            <div className="modal-category">{offer.categories.icon} {offer.categories.name_ar}</div>
          )}
          <h2 className="modal-title">{offer.title_ar}</h2>
          <p className="modal-desc">{offer.description_ar}</p>
          <div className="modal-pricing">
            <span className="modal-price-offer">{offer.offer_price.toLocaleString('ar-DZ')} د.ج</span>
            <span className="modal-price-original">{offer.original_price.toLocaleString('ar-DZ')} د.ج</span>
            <span className="modal-discount">وفّر {discount}%</span>
          </div>
          <div className="modal-actions">
            <button className="btn-primary" onClick={handleShare}>
              📤 مشاركة العرض
            </button>
            <button className="btn-secondary" onClick={onClose}>
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function OfferCard({ offer, onClick }: { offer: Offer; onClick: () => void }) {
  const discount = calcDiscount(offer.original_price, offer.offer_price);
  const badgeClass = BadgeClass(offer.badge);

  function handleShare(e: React.MouseEvent) {
    e.stopPropagation();
    const text = `عرض بروفون: ${offer.title_ar}\n💰 ${offer.offer_price.toLocaleString('ar-DZ')} د.ج (كان ${offer.original_price.toLocaleString('ar-DZ')} د.ج)\nوفّر ${discount}%`;
    if (navigator.share) {
      navigator.share({ title: 'عرض بروفون', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text).then(() => {});
    }
  }

  return (
    <div className="offer-card" onClick={onClick}>
      <div className="card-image-wrap">
        <img src={offer.image_url} alt={offer.title_ar} loading="lazy" />
        {offer.badge_ar && (
          <span className={`card-badge ${badgeClass}`}>{offer.badge_ar}</span>
        )}
      </div>
      <div className="card-body">
        {offer.categories && (
          <div className="card-category">{offer.categories.icon} {offer.categories.name_ar}</div>
        )}
        <h3 className="card-title">{offer.title_ar}</h3>
        <p className="card-desc">{offer.description_ar}</p>
        <div className="card-pricing">
          <span className="price-offer">{offer.offer_price.toLocaleString('ar-DZ')} د.ج</span>
          <span className="price-original">{offer.original_price.toLocaleString('ar-DZ')} د.ج</span>
          <span className="discount-badge">-{discount}%</span>
        </div>
        <div className="card-footer">
          <ExpiresLabel expiresAt={offer.expires_at} />
          <button className="share-btn" onClick={handleShare}>
            📤 شارك
          </button>
        </div>
      </div>
    </div>
  );
}

const TICKER_ITEMS = [
  '⚡ عروض حصرية كل أسبوع',
  '📱 أحدث الهواتف بأسعار مميزة',
  '🎧 إكسسوارات أصلية',
  '🔧 صيانة وإصلاح محترف',
  '⭐ ضمان على جميع المنتجات',
  '🚀 توصيل سريع',
];

export default function App() {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [{ data: cats }, { data: offs }] = await Promise.all([
      supabase.from('categories').select('*').order('name_ar'),
      supabase
        .from('offers')
        .select('*, categories(*)')
        .eq('is_active', true)
        .order('created_at', { ascending: false }),
    ]);
    if (cats) setCategories(cats);
    if (offs) setOffers(offs as Offer[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = offers.filter((o) => {
    const matchCat = selectedCat === 'all' || o.category_id === selectedCat;
    const q = search.trim().toLowerCase();
    const matchSearch = !q || o.title_ar.toLowerCase().includes(q) || o.description_ar.toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  const totalSavings = filtered.reduce((acc, o) => acc + (o.original_price - o.offer_price), 0);

  return (
    <>
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <div className="logo-icon">📱</div>
            <div className="logo-text">
              <span className="brand">ProPhone</span>
              <span className="tagline">بروفون - عروض الهواتف</span>
            </div>
          </div>
          <div className="header-search">
            <span className="search-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
            </span>
            <input
              type="text"
              placeholder="ابحث عن عرض..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </header>

      <div className="ticker" aria-hidden="true">
        <div className="ticker-track">
          {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
            <span key={i} className="ticker-item">{item}</span>
          ))}
        </div>
      </div>

      <section className="hero">
        <div className="hero-content">
          <div className="hero-badge">✨ عروض حصرية</div>
          <h1>
            أفضل عروض <span>الهواتف</span><br />والإلكترونيات
          </h1>
          <p>وفّر أكثر مع عروض بروفون المميزة — اكتشف أحدث العروض الآن</p>
          <div className="hero-stats">
            <div className="hero-stat">
              <span className="num">{offers.length}</span>
              <span className="lbl">عرض نشط</span>
            </div>
            <div className="hero-stat">
              <span className="num">{categories.length}</span>
              <span className="lbl">فئة</span>
            </div>
            <div className="hero-stat">
              <span className="num">
                {totalSavings > 0 ? `${Math.round(totalSavings / filtered.length).toLocaleString('ar-DZ')} د.ج` : '—'}
              </span>
              <span className="lbl">متوسط التوفير</span>
            </div>
          </div>
        </div>
      </section>

      <main className="main">
        <div className="section-title">الفئات</div>
        <div className="categories">
          <button
            className={`cat-btn ${selectedCat === 'all' ? 'active' : ''}`}
            onClick={() => setSelectedCat('all')}
          >
            <span className="cat-icon">🏷</span> الكل
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`cat-btn ${selectedCat === cat.id ? 'active' : ''}`}
              onClick={() => setSelectedCat(cat.id)}
            >
              <span className="cat-icon">{cat.icon}</span>
              {cat.name_ar}
            </button>
          ))}
        </div>

        <div className="offers-header">
          <div className="section-title">العروض المتاحة</div>
          <div className="offers-count">
            {loading ? 'جاري التحميل...' : `${filtered.length} عرض`}
          </div>
        </div>

        {loading ? (
          <div className="loading-container">
            <div className="loading-spinner" />
            <div className="loading-text">جاري تحميل العروض...</div>
          </div>
        ) : (
          <div className="offers-grid">
            {filtered.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🔍</div>
                <h3>لا توجد عروض</h3>
                <p>جرّب تغيير الفئة أو كلمة البحث</p>
              </div>
            ) : (
              filtered.map((offer, idx) => (
                <div key={offer.id} style={{ animationDelay: `${idx * 0.05}s` }}>
                  <OfferCard offer={offer} onClick={() => setSelectedOffer(offer)} />
                </div>
              ))
            )}
          </div>
        )}
      </main>

      <footer className="footer">
        <div className="footer-inner">
          <div className="footer-brand">📱 ProPhone — بروفون</div>
          <div className="footer-text">
            متجر الهواتف والإلكترونيات — أفضل الأسعار وأحدث العروض
          </div>
        </div>
      </footer>

      {selectedOffer && (
        <OfferModal offer={selectedOffer} onClose={() => setSelectedOffer(null)} />
      )}
    </>
  );
}
