import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Category = {
  id: string;
  name: string;
  name_ar: string;
  icon: string;
  created_at: string;
};

export type Offer = {
  id: string;
  title: string;
  title_ar: string;
  description: string;
  description_ar: string;
  original_price: number;
  offer_price: number;
  image_url: string;
  category_id: string | null;
  badge: string;
  badge_ar: string;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
  categories?: Category;
};
